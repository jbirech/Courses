<?php
if(isset($_POST['loginButton'])) {
	//Login button was pressed
	
}
?>