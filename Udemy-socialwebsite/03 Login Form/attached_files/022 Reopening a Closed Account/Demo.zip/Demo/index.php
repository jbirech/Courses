<?php  
require 'config/config.php';

?>

<html>
<head>
	<title>Welcome to Swirlfeed</title>
</head>
<body>
	Hello Reece!!!!!
</body>
</html>